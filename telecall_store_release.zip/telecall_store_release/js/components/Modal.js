export const deleteModal = ({
    id = "",
    body = "",
    deleteButtonId = "",
    extraBodyHtml = "",
}) => {
    return (`<div class="modal fade" id="${id}">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header head" style="border:0px;">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body head message-modal" style="justify-content: center;">
                    <div class="box-group message-group" id="accordion">
                          ${extraBodyHtml}
                            <div style="align-self: center;
                                        background: red;
                                        padding: 4px;
                                        color: white;
                                        border-radius: 100px;
                                        font-size: 22px;
                                        height: 35px !important;
                                        width: 35px !important;!i;!;
                                        text-align: center;
                                        margin-top: -32px;
                                        margin-bottom: 10px;
                                    "> X </div>
                        <span class="message-text" style="color: gray;
                                                          align-self: center;
                                                          padding: 10px;
                                                        ">${body}</span>
                    </div>
                </div>
                <div class="modal-footer" style="border:0px;">
                    <button type="button" class="btn delete-button modal-buttons-save ${deleteButtonId} pull-left">Delete</button>
                    <button type="button" class="modal-buttons btn btn-default" data-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </div>`)
}