/*
 * JsSIP waits for Chrome's ICE gathering state to become "complete" before it
 * sends the initial INVITE. A failed STUN probe can keep that state at
 * "gathering" for roughly 40 seconds even though usable candidates are ready.
 *
 * JsSIP exposes ready() on its icecandidate event specifically so an
 * application can stop gathering and continue with the candidates collected
 * so far. Prefer a server-reflexive/relay candidate, with a short host-only
 * fallback for networks where STUN is unavailable.
 */
(function enableFastIceGathering() {
  "use strict";

  if (!window.session || typeof window.session.sessionHandler !== "function") {
    return;
  }

  const originalSessionHandler = window.session.sessionHandler;

  window.session.sessionHandler = function sessionHandlerWithFastIce(rtcSession) {
    let gatheringTimer = null;
    let gatheringFinished = false;

    const finishGathering = (ready) => {
      if (gatheringFinished || typeof ready !== "function") {
        return;
      }

      gatheringFinished = true;
      if (gatheringTimer !== null) {
        clearTimeout(gatheringTimer);
        gatheringTimer = null;
      }
      ready();
    };

    rtcSession.on("icecandidate", ({ candidate, ready }) => {
      const candidateText = candidate && candidate.candidate || "";
      const candidateType = candidate && candidate.type ||
        (candidateText.match(/\btyp\s+(host|srflx|prflx|relay)\b/i) || [])[1];

      if (candidateType === "srflx" || candidateType === "relay") {
        finishGathering(ready);
        return;
      }

      if (gatheringTimer === null) {
        gatheringTimer = setTimeout(() => {
          const peerConnection = rtcSession.connection;
          if (!peerConnection || peerConnection.iceGatheringState !== "complete") {
            finishGathering(ready);
          }
        }, 1500);
      }
    });

    return originalSessionHandler.call(this, rtcSession);
  };
})();
