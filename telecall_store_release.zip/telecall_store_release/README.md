 
# TeleCall 
TeleCall là tiện ích gọi điện trên trình duyệt

# Key Features:
1) Call Type
- Audio Call
<!-- - Video Call -->
2) Call Assitant
- Do Not Disturb
- Auto Answer Incoming Calls

# Call Features:
- Hold/Unhold
- Mute/Unmute
- Send DTMF
- 100rel (Early Media Support)
- Call Transfer (Blind)

# How to use
- Install Chrome Extension from this link : chrome store link.
- Click on Chrome Extension Icon in toolbar
- If you're not logged in, it will open new window to enter credentials
- Enter requested permission for Microphone and Camera
- Click on 'Add Account' button
- Click on Chrome Extension Icon in toolbar, it will open dialpad in popup window
- Enter the number and click on Audio/Video button to dial entered number
- Enjoy it!

# Frequently Asked Questions
1) Quetion 1 ?
- Answer.
2) Quetion 2 ?
- Answer.
3) Quetion 3 ?
- Answer.
4) Quetion 4 ?
- Answer.
5) Quetion 5 ?
- Answer.


# Upcoming Features
- Attended Transfer
- Local Call History Suppport
- Local Phonebook Support
- Remote Phonebook Support
- Enable Click2Call support from any webpage
 
- E-mail: doremi.lienhe@gmail.com 
 
